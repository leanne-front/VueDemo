<template>
  <div id="app">
    <main>
      <h1>Covid-19 Tracking demo</h1>
    </main>
  </div>
</template>

<script>
import axios from 'axios'
import Vue from 'vue'
import App from './App'

console.log('[i] Starting client app')

Vue.config.productionTip = false

new Vue({ el: '#app', render: h => h(App) })

export default {
  name: 'App',

  components: {
    data(){
      return {}
    }
  },
  async created(){
    let {data} = await axios.get(
       'https://api.covidtracking.com/v1/us/daily.json'
    )
    console.log(data)
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
